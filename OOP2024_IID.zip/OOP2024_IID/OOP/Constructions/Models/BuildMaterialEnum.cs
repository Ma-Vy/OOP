﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Constructions.Models
{
    internal enum BuildMaterialEnum
    {
        Brik = 0,
        Wood = 10,
        Concrete = 20
    }
}
