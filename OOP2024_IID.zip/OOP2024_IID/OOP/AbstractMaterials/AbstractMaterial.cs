﻿using OOP.Constructions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.AbstractMaterials
{
    abstract class AbstractMaterial : Construction
    {
        protected double MaterialCost;
        public abstract double CalculateMaterialCost();
    }

    class WoodMaterial : AbstractMaterial
    {
        public WoodMaterial()
        {
            MaterialCost = 300;
        }
        public override double CalculateMaterialCost()
        {
            return MaterialCost;
        }
    }

    class BrikMaterial : AbstractMaterial
    {
        public BrikMaterial()
        {
            MaterialCost = 100;
        }
        public override double CalculateMaterialCost()
        {
            return MaterialCost;
        }
    }

    class ConcreteMaterial : AbstractMaterial
    {
        public ConcreteMaterial()
        {
            MaterialCost = 200;
        }
        public override double CalculateMaterialCost()
        {
            return MaterialCost;
        }
    }

}
